package es.club.nautico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringClubNauticoApplicationTests {

	@Test
	void contextLoads() {
	}

}
