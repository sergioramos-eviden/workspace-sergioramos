package es.club.nautico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringClubNauticoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringClubNauticoApplication.class, args);
	}

}
